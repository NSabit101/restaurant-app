import React, { useState } from 'react';
import { signUp } from '../api/api';
import { useNavigate } from 'react-router-dom';

export default function SignUp() {
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    try {
      const data = await signUp(formData);
      if (data._id) {
        alert('Sign up successful! Please sign in.');
        navigate('/signin');
      } else {
        setError(data.message || 'Error signing up');
      }
    } catch {
      setError('Error signing up');
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ padding: '20px', maxWidth: '400px' }}>
      <h2>Sign Up</h2>
      {error && <p style={{color: 'red'}}>{error}</p>}
      <label>
        Name:<br />
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
      </label>
      <br /><br />
      <label>
        Email:<br />
        <input type="email" name="email" value={formData.email} onChange={handleChange} required />
      </label>
      <br /><br />
      <label>
        Password:<br />
        <input type="password" name="password" value={formData.password} onChange={handleChange} required />
      </label>
      <br /><br />
      <button type="submit">Sign Up</button>
    </form>
  );
}
