import React, { useEffect, useState } from 'react';
import { fetchMenuItems, deleteMenuItem } from '../api/api';
import { useNavigate } from 'react-router-dom';

export default function HomePage({ isLoggedIn }) {
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMenuItems().then(data => {
      setMenuItems(data);
      setLoading(false);
    });
  }, []);

  async function handleDelete(id) {
    if (window.confirm('Are you sure you want to delete this item?')) {
      await deleteMenuItem(id);
      setMenuItems(menuItems.filter(item => item._id !== id));
    }
  }

  return (
    <div style={{ padding: '20px' }}>
      <h1>Menu</h1>
      {loading ? (
        <p>Loading menu items...</p>
      ) : menuItems.length === 0 ? (
        <p>No menu items found.</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {menuItems.map(item => (
            <li key={item._id} style={{ marginBottom: '15px', borderBottom: '1px solid #ddd', paddingBottom: '10px' }}>
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <p><strong>Price:</strong> ${item.price.toFixed(2)}</p>
              {isLoggedIn && (
                <>
                  <button onClick={() => navigate(`/edit/${item._id}`)} style={{ marginRight: '10px' }}>
                    Edit
                  </button>
                  <button onClick={() => handleDelete(item._id)} style={{ backgroundColor: 'red', color: 'white' }}>
                    Delete
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
      {isLoggedIn && (
        <button onClick={() => navigate('/add')} style={{ marginTop: '20px' }}>
          Add New Menu Item
        </button>
      )}
    </div>
  );
}
