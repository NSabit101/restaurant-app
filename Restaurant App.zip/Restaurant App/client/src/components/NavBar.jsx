import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

export default function NavBar({ isLoggedIn, setIsLoggedIn }) {
  const navigate = useNavigate();

  function handleSignOut() {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    navigate('/signin');
  }

  const linkStyle = ({ isActive }) => ({
    marginRight: '15px',
    fontWeight: isActive ? 'bold' : 'normal',
    textDecoration: isActive ? 'underline' : 'none',
  });

  return (
    <nav style={{ padding: '10px', borderBottom: '1px solid #ddd', display: 'flex', alignItems: 'center' }}>
      <img src="/logo.png" alt="Foodies United Logo" style={{ height: '40px', marginRight: '15px' }} />
      <NavLink to="/" style={linkStyle} end>Home</NavLink>
      {isLoggedIn ? (
        <>
          <NavLink to="/myprofile" style={linkStyle}>My Profile</NavLink>
          <button onClick={handleSignOut} style={{ cursor: 'pointer', marginLeft: 'auto' }}>Sign Out</button>
        </>
      ) : (
        <>
          <NavLink to="/signin" style={linkStyle}>Sign In</NavLink>
          <NavLink to="/signup" style={linkStyle}>Sign Up</NavLink>
        </>
      )}
    </nav>
  );
}
