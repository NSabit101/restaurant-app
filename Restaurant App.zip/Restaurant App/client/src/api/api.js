const API_BASE = 'http://localhost:5000/api';

function getAuthHeaders() {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function fetchMenuItems() {
  const res = await fetch(`${API_BASE}/menu-items`);
  return res.json();
}

export async function createMenuItem(data) {
  const res = await fetch(`${API_BASE}/menu-items`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateMenuItem(id, data) {
  const res = await fetch(`${API_BASE}/menu-items/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteMenuItem(id) {
  const res = await fetch(`${API_BASE}/menu-items/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  return res.json();
}

export async function signIn(credentials) {
  const res = await fetch(`${API_BASE}/users/signin`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(credentials),
  });
  return res.json();
}

export async function signUp(userData) {
  const res = await fetch(`${API_BASE}/users/signup`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(userData),
  });
  return res.json();
}

export async function fetchUserProfile() {
  const res = await fetch(`${API_BASE}/users/profile`, {
    headers: getAuthHeaders(),
  });
  return res.json();
}
