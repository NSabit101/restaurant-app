import React, { useEffect, useState } from 'react';
import { createMenuItem, updateMenuItem, fetchMenuItems } from '../api/api';
import { useNavigate, useParams } from 'react-router-dom';

export default function MenuItemForm() {
  const [formData, setFormData] = useState({ name: '', description: '', price: '', available: true });
  const [loading, setLoading] = useState(false);
  const { id } = useParams(); // If editing, URL param will have id
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      // Load existing menu item for editing
      fetch(`/api/menu-items/${id}`)
        .then(res => res.json())
        .then(data => {
          setFormData({ 
            name: data.name, 
            description: data.description, 
            price: data.price, 
            available: data.available 
          });
        });
    }
  }, [id]);

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      if (id) {
        await updateMenuItem(id, { 
          name: formData.name, 
          description: formData.description, 
          price: Number(formData.price), 
          available: formData.available 
        });
      } else {
        await createMenuItem({ 
          name: formData.name, 
          description: formData.description, 
          price: Number(formData.price), 
          available: formData.available 
        });
      }
      navigate('/');
    } catch (error) {
      alert('Error saving menu item');
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ padding: '20px', maxWidth: '400px' }}>
      <h2>{id ? 'Edit Menu Item' : 'Add New Menu Item'}</h2>
      <label>
        Name:<br />
        <input type="text" name="name" value={formData.name} onChange={handleChange} required />
      </label>
      <br /><br />
      <label>
        Description:<br />
        <textarea name="description" value={formData.description} onChange={handleChange} required />
      </label>
      <br /><br />
      <label>
        Price:<br />
        <input type="number" name="price" value={formData.price} onChange={handleChange} required min="0" step="0.01" />
      </label>
      <br /><br />
      <label>
        Available: 
        <input type="checkbox" name="available" checked={formData.available} onChange={handleChange} />
      </label>
      <br /><br />
      <button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save'}</button>
    </form>
  );
}
