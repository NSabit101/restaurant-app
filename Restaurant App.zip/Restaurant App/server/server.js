import express from "express";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors";
import menuItemRoutes from "./routes/menuItem.routes.js";
import userRoutes from "./routes/user.routes.js";

dotenv.config();

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Routes
app.use("/api/menu-items", menuItemRoutes);
app.use("/api/users", userRoutes);

console.log("Connecting to MongoDB at:", process.env.MONGO_URI);

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log("MongoDB connected successfully");
  
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
})
.catch((err) => {
  console.error("MongoDB connection error:", err);
  process.exit(1);
});

app.get("/", (req, res) => {
  res.send("Welcome to Restaurant App API");
});
